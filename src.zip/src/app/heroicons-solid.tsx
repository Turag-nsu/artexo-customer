"use client";

import HeroiconsSolid from "@heroicons/react/24/solid";

export default HeroiconsSolid;
