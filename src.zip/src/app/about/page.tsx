'use client';

import React from 'react';
import rightImg from '@/images/hero-right1.png';
import SectionHero from './SectionHero';
import BgGlassmorphism from '@/components/BgGlassmorphism/BgGlassmorphism';
import BackgroundSection from '@/components/BackgroundSection/BackgroundSection';
import { siteName } from '@/lib/config';
interface SectionMissionProps {
  title: string;
  content: string[];
}

const SectionMission: React.FC<SectionMissionProps> = ({ title, content }) => {
  return (
    <div className="space-y-8 px-4 sm:px-8 lg:px-16">
      <h2 className="text-3xl font-bold text-center sm:text-left text-gray-800 dark:text-gray-200">
      {title}
      </h2>
      <ul className="list-disc pl-5 space-y-4 text-gray-600 dark:text-gray-400">
      {content.map((item, index) => (
        <li
        key={index}
        className="text-lg leading-relaxed sm:text-xl sm:leading-loose"
        >
        {item}
        </li>
      ))}
      </ul>
    </div>
  );
}
const PageAbout: React.FC = () => {
  return (
    <div className="nc-PageAbout relative overflow-hidden">
      <BgGlassmorphism />
      <BackgroundSection className="absolute inset-0" />

      <div className="container mx-auto py-16 lg:py-28 space-y-24">
        {/* Hero Section */}
        <SectionHero
          rightImg={rightImg}
          heading="🧕 Hijab: An Inspiration"
          subHeading={`The hijab is more than a garment—it's a symbol of dignity, faith, and empowerment for women everywhere.`}
          btnText=""
        />

        {/* Mission Section */}
        <SectionMission
          title="Why Women Should Wear Hijab"
          content={[
            "The hijab is a source of inspiration, representing modesty, self-respect, and inner strength.",
            "Wearing hijab allows women to express their identity and values with confidence, free from societal pressures to conform to external standards.",
            "It fosters a sense of belonging and unity among women, connecting them to a rich tradition of faith and culture.",
            "The hijab empowers women to be recognized for their intellect, character, and achievements rather than appearance.",
            "Choosing hijab is a personal act of devotion and self-empowerment, inspiring others to embrace authenticity and self-worth."
          ]}
        />
      </div>
    </div>
  );
};

export default PageAbout;
